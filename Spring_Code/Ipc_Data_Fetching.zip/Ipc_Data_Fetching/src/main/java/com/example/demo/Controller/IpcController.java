package com.example.demo.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Ipc.Ipc;
import com.example.demo.Service.IpcServiceImplementation;

import java.util.List;

@RestController
@RequestMapping("/ipc")
public class IpcController {

    private IpcServiceImplementation ipcService;

    public IpcController(IpcServiceImplementation ipcService) {
        this.ipcService = ipcService;
    }

    @GetMapping("/List")
    public List<Ipc> getAllIpc() {
        return ipcService.getAllIpc();
    }
    
    @GetMapping("/List/{id}")
    public Ipc getByIpc(@PathVariable("id")int ipc) {
    	return ipcService.getByIpc(ipc);
    }
}