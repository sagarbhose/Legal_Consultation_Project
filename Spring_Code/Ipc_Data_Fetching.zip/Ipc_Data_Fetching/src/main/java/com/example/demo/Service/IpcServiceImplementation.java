package com.example.demo.Service;

import java.nio.file.Files;
import java.util.List;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;


import java.io.IOException;
import java.nio.file.Path;


import com.example.demo.Ipc.Ipc;

@Service
public class IpcServiceImplementation implements IpcServiceDeclaration {

	private final ObjectMapper objectMapper;

    public IpcServiceImplementation(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }
    public List<Ipc> getAllIpc() {
        List<Ipc> ipcList = null;

        try {
            byte[] jsonData = Files.readAllBytes(Path.of("src/main/resources/ipc_id.json"));
            ipcList = objectMapper.readValue(jsonData, new TypeReference<List<Ipc>>() {});
        } catch (IOException e) {
            e.printStackTrace();
        }

        return ipcList;
    }
	@Override
	public Ipc getByIpc(int ipc) {
		Ipc ans=null;
		List<Ipc>l=getAllIpc();
		for(Ipc it:l) {
			if(ipc==it.getSection()) {
				ans=it;
			}
		}
		return ans;
	}

}
