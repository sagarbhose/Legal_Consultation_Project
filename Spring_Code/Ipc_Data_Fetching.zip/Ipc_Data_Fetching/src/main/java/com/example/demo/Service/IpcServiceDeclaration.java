package com.example.demo.Service;

import java.util.List;

import com.example.demo.Ipc.Ipc;

public interface IpcServiceDeclaration {

	public List<Ipc> getAllIpc();
	public Ipc getByIpc(int ipc);
}
